package shobu;

public class ShobuBoard { //Two Homeboards objects with a digital String separating them
	Homeboards playerOneHomeboards;
	Homeboards playerTwoHomeboards;
	
	public ShobuBoard(Homeboards topHomeboards, Homeboards bottomHomeboards) { //Constructor from top and bottom Homeboards constructor
		playerTwoHomeboards = topHomeboards;
		playerOneHomeboards = bottomHomeboards;
	}
	
	public String toString() { //String representation of a ShobuBoard
		StringBuffer ShobuBoard = new StringBuffer();
		ShobuBoard.append(playerTwoHomeboards.toString());
		ShobuBoard.append(">-----------------<" + System.lineSeparator());
		ShobuBoard.append(playerOneHomeboards.toString());
		return ShobuBoard.toString();
	}
}
