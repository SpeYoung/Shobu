package shobu;

public class Player {
	boolean stoneColourBlack;
	boolean humanPlayer;
	int wins;
	public Player(char Colour, boolean humanPlayer) {
		if(Colour == 'B') {
			stoneColourBlack = true;
		}
		if(Colour == 'W') {
			stoneColourBlack = false;
		}
		this.humanPlayer = humanPlayer;
	}
	public boolean isBlack() {
		return stoneColourBlack;
	}
	public boolean isHuman() {
		return humanPlayer;
	}
}
