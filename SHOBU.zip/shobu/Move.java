package shobu;

public abstract class Move { 
	protected  Player player; 
	protected  Board board; 
	protected  int startX;
	protected  int startY;
	protected int endX;
	protected  int endY;
	public Move(Player player, Board board, int startX, int startY, int endX, int endY) 
	{ 
		this.player = player; 
		this.board = board;
		this.startX = startX;
		this.startY = startY;
		this.endX = endX; 
		this.endY = endY; 
	} 
	public abstract boolean canMove();
} 

