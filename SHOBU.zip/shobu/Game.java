package shobu;
import java.util.ArrayList;
import java.util.List;

public class Game { //Instance of Shobu game
	Player playerOne;
	Player playerTwo;
	ShobuBoard gameState;
	private GameStatus status;
	public List<Move> movesPlayed = new ArrayList<>();
	Player currentTurn;
	
	void initialize(Player playerOne, Player playerTwo) {
		this.playerOne = playerOne;
		this.playerTwo = playerTwo;
		gameState = newGame();
		currentTurn = this.playerOne;
		setStatus(GameStatus.ACTIVE);
		//movesPlayed.clear();
	}
	
	static ShobuBoard newGame() { //Sets ShobuBoard to a new game state
		int quad = 1;
		Board boardOne = new Board(quad);
		quad++;
		Board boardTwo = new Board(quad);
		Homeboards playerTwoHomeboards = new Homeboards(boardTwo, boardOne);
		quad++;
		Board boardThree = new Board(quad);
		quad++;
		Board boardFour = new Board(quad);
		Homeboards playerOneHomeboards = new Homeboards(boardThree, boardFour);
		ShobuBoard ShobuGameBoard = new ShobuBoard(playerTwoHomeboards, playerOneHomeboards);
		return ShobuGameBoard;
	}
	
	static boolean Move(Player turn) {
		return true;
	}
	
	public GameStatus getStatus() {
		return status;
	}

	public void setStatus(GameStatus status) {
		this.status = status;
	}

	public enum GameStatus {
		ACTIVE,
		BLACK_WIN,
		WHITE_WIN,
		STALEMATE
	}
	
}
