package shobu;

public class Board { //Two dimensional matrix representation of a 4x4 grid which has a colour and belongs to a player's Homeboards
	char [][] board = {{'W', 'W', 'W', 'W'},//| B = Black stone, W = White stone, and ' ' (Space) is an empty space
			{' ', ' ', ' ', ' '},
			{' ', ' ', ' ', ' '},
			{'B', 'B', 'B', 'B'}}; //4 White stones on top row, and 4 Black stones on bottom row
	char colour; //D = Dark, L = Light
	char quandrant;
	
	public Board(int quadrant) { //Constructor for initial state depending on which quadrant the Board represents
		if(quadrant == 1) {
			colour = 'L';
			this.quandrant = 'b';
		}
		else if(quadrant == 2) {
			colour = 'D';
			this.quandrant = 'a';
		}
		else if(quadrant == 3) {
			colour = 'D';
			this.quandrant = 'c';
		}
		else if(quadrant == 4) {
			colour = 'L';
			this.quandrant = 'd';
		}
	}
	
	public String toString() { //String representation of a Board with -, |, and + characters used to represent the board
		StringBuffer boardString = new StringBuffer();
		boardString.append("---------" + System.lineSeparator());
		for(int r=0; r<board.length; r++) {
			for(int c=0; c<board.length; c++) {
				boardString.append("|" + board[r][c]);
			}
			if(r < board.length-1) {
				boardString.append('|' + System.lineSeparator() + "|-+-+-+-|" + System.lineSeparator());
			}
		}
		boardString.append('|' + System.lineSeparator() + "---------" + System.lineSeparator());
		return boardString.toString();
	}
	
	public char getSpace(int x, int y) {
		return board[x][y];
	}
	
	public void move(Move movement) {
		board[movement.endX][movement.endY] = board[movement.startX][movement.startY];
		board[movement.startX][movement.startY] = ' ';
	}
	
	public boolean isDark() {
		if(colour == 'D') {
			return true;
		}else {
			return false;
		}
	}
	
}
