
package shobu;
import java.util.Scanner;

import shobu.Game.GameStatus;

public class Shobu {
	static int whiteTopLeftWin = 0;
	static int whiteBottomLeftWin = 0;
	static int whiteTopRightWin = 0;
	static int whiteBottomRightWin = 0;
	static int blackTopLeftWin = 0;
	static int blackBottomLeftWin = 0; 
	static int blackTopRightWin = 0;
	static int blackBottomRightWin = 0;
	public static void main(String[] args) {
		int blackWin = 0;
		int whiteWin = 0;
		int draws = 0;
		int turns = 0;
		int totalTurns = 0;
		int totalNonStalemateGames = 0;
		for(int x = 0; x < 100; x++) {
			Game game = newGame(); //new game state
			System.out.println(game.gameState); //print initial game state
			while(game.getStatus().toString() == "ACTIVE") { //game loop while active
				if(game.currentTurn.isBlack()) { System.out.println("Player 1 turn:(Black)"); }else { System.out.println("Player 2 turn:(White)"); } //prints the current player turn
				playerTurn(game); //updates the game state for a player's turn
				turns++;
				if(turns > 10000) {
					draws++;
					game.setStatus(GameStatus.STALEMATE);
				}
				if(winner(game)) { //check for winner
					if(game.currentTurn.isBlack()) { //sets game status to win from active
						game.setStatus(GameStatus.BLACK_WIN);
					}
					else {
						game.setStatus(GameStatus.WHITE_WIN);
					}
				}
				if(game.currentTurn.isBlack()) { //switch player turn
					game.currentTurn = game.playerTwo;
				}
				else {
					game.currentTurn = game.playerOne;
				}
				System.out.println(game.gameState); //prints out the game state
			}
			System.out.println("The game has resulted in a " + game.getStatus()); //winner declaration
			if(game.getStatus().toString() == "BLACK_WIN") {
				blackWin++;
			}
			else if(game.getStatus().toString() == "WHITE_WIN"){
				whiteWin++;
			}
			if(!(game.getStatus().toString() == "STALEMATE")) {
				totalTurns += turns;
				totalNonStalemateGames++;
			}
			turns = 0;
		}
		System.out.println("Black wins: " + blackWin);
		System.out.println("White wins: " + whiteWin);
		System.out.println("Draws: " + draws);
		System.out.println("Average turns per non-draw game: " + totalTurns/totalNonStalemateGames);
		System.out.println("Top left white wins: " + whiteTopLeftWin);
		System.out.println("Top right white wins: " + whiteTopRightWin);
		System.out.println("Bottom left white wins: " + whiteBottomLeftWin);
		System.out.println("Bottom right white wins: " + whiteBottomRightWin);
		System.out.println("Top left black wins: " + blackTopLeftWin);
		System.out.println("Top right black wins: " + blackTopRightWin);
		System.out.println("Bottom left black wins: " + blackBottomLeftWin);
		System.out.println("Bottom right black wins: " + blackBottomRightWin);
	}
	
	public static void playerTurn(Game game) {
		if(game.currentTurn.isHuman()) {
			@SuppressWarnings("resource")
			Scanner myObj = new Scanner(System.in);  // Create a Scanner object
			boolean moveValid = false;
			while(!moveValid) {
				System.out.println("Passive move:");
				System.out.println("Enter start space i.e. (c30):"); //Start space input
			    String startSpace = "" + myObj.nextLine();  // Read start space user input
			    System.out.println("Enter end space i.e. (c20):");  //End space input
			    String endSpace = "" + myObj.nextLine();  // Read start space user input
			    Board passMoveBoard = null;
			    if(startSpace.contains("a")) {
			    	passMoveBoard = game.gameState.playerTwoHomeboards.leftBoard;
			    }
			    else if(startSpace.contains("b")){
			    	passMoveBoard = game.gameState.playerTwoHomeboards.rightBoard;
			    }
			    else if(startSpace.contains("c")){
			    	passMoveBoard = game.gameState.playerOneHomeboards.leftBoard;
			    }
			    else if(startSpace.contains("d")){
			    	passMoveBoard = game.gameState.playerOneHomeboards.rightBoard;
			    }
			    Move passMove = new PassiveMove(game.currentTurn, passMoveBoard, Integer.parseInt(startSpace.substring(1, 2)), Integer.parseInt(startSpace.substring(2, 3)), Integer.parseInt(endSpace.substring(1, 2)), Integer.parseInt(endSpace.substring(2, 3)));
			    if(passMove.canMove()){
			    	System.out.println("Aggressive move:");
			    	System.out.println("Enter start space i.e. (d30):"); //Start space input
				    startSpace = "" + myObj.nextLine();  // Read start space user input
				    System.out.println("Enter end space i.e. (d20):");  //End space input
				    endSpace = "" + myObj.nextLine();  // Read start space user input
				    Board aggroMoveBoard = null;
				    if(startSpace.contains("a")) {
				    	aggroMoveBoard = game.gameState.playerTwoHomeboards.leftBoard;
				    }
				    else if(startSpace.contains("b")){
				    	aggroMoveBoard = game.gameState.playerTwoHomeboards.rightBoard;
				    }
				    else if(startSpace.contains("c")){
				    	aggroMoveBoard = game.gameState.playerOneHomeboards.leftBoard;
				    }
				    else if(startSpace.contains("d")){
				    	aggroMoveBoard = game.gameState.playerOneHomeboards.rightBoard;
				    }
				    Move aggroMove = new AggressiveMove(passMove, aggroMoveBoard, Integer.parseInt(startSpace.substring(1, 2)), Integer.parseInt(startSpace.substring(2, 3)), Integer.parseInt(endSpace.substring(1, 2)), Integer.parseInt(endSpace.substring(2, 3)));
				    if(aggroMove.canMove()) {
				    	passMoveBoard.move(passMove);
				    	game.movesPlayed.add(passMove);
				    	aggroMoveBoard.move(aggroMove);
				    	game.movesPlayed.add(aggroMove);
				    	moveValid = true;
				    }
				    else {
				    	System.out.println("Invalid aggressive move, please try again!"); //invalid Aggressive move
				    }
			    }
			    else {
			    	System.out.println("Invalid passive move, please try again!"); //invalid Passive move
			    }
			}
		}else { //computer player turn
			int moveAttempts = 0;
			if(game.currentTurn.isBlack()) { //computer player is black
				int max = 2; 
		        int min = 1; 
		        int range = max - min + 1; 
		        boolean validMove = false;
		        Board passMoveBoard = null;
		        Board aggroMoveBoard = null;
		        int randOne = 0;
		        int randTwo = 0;
		        int randThree = 0;
		        int randFour = 0;
		        PassiveMove tempPassMove = null;
		        AggressiveMove tempAggroMove;
				while(!validMove) {
					moveAttempts++;
					if(moveAttempts > 1000000) {
						game.setStatus(GameStatus.WHITE_WIN);
						validMove = true;
					}
					boolean validPassMove = false;
			        while(!validPassMove) {
			        	max = 2;
			        	min = 1;
			        	range = max - min + 1;
				        randOne = (int)(Math.random() * range) + min;
				        if(randOne == 1) {
				        	passMoveBoard = game.gameState.playerOneHomeboards.leftBoard;
				        } else {
				        	passMoveBoard = game.gameState.playerOneHomeboards.rightBoard;
				        }
				        max = 3;
			        	min = 0;
			        	range = max - min + 1;
			        	boolean validSpot = false;
				        while(!validSpot) {
				        	randOne = (int)(Math.random() * range) + min;
				        	randTwo = (int)(Math.random() * range) + min;
					        if(passMoveBoard.board[randOne][randTwo] == 'B') {
					            		validSpot = true;
					        }
				        }
			        	randThree = (int)(Math.random() * range) + min;
			        	randFour = (int)(Math.random() * range) + min;
			        	tempPassMove = new PassiveMove(game.currentTurn, passMoveBoard, randOne, randTwo, randThree, randFour);
				        if(tempPassMove.canMove()) {
				        	validPassMove = true;
				        }
			        }
			        if(passMoveBoard.isDark()) {//passive move was on dark coloured board
			        	max = 2;
			        	min = 1;
			        	range = max - min + 1;
			        	randOne = (int)(Math.random() * range) + min;
			        	if(randOne == 1) {
				        	aggroMoveBoard = game.gameState.playerTwoHomeboards.rightBoard;
				        } else {
				        	aggroMoveBoard = game.gameState.playerOneHomeboards.rightBoard;
				        }
				        max = 3;
			        	min = 0;
			        	range = max - min + 1;
			        	boolean validSpot = false;
				        while(!validSpot) {
				        	randOne = (int)(Math.random() * range) + min;
				        	randTwo = (int)(Math.random() * range) + min;
					        if(aggroMoveBoard.board[randOne][randTwo] == 'B') {
					            		validSpot = true;
					        }
				        }
				        randThree = (int)(Math.random() * range) + min;
			        	randFour = (int)(Math.random() * range) + min;
				        tempAggroMove = new AggressiveMove(tempPassMove, aggroMoveBoard, randOne, randTwo, randThree, randFour);
				        if(tempAggroMove.canMove()) {
				        	passMoveBoard.move(tempPassMove);
					    	game.movesPlayed.add(tempPassMove);
					    	aggroMoveBoard.move(tempAggroMove);
					    	game.movesPlayed.add(tempAggroMove);
				        	validSpot = true;
				        	validMove = true;
				        }
			        }else { //passive move was on light coloured board
			        	max = 2;
			        	min = 1;
			        	range = max - min + 1;
			        	randOne = (int)(Math.random() * range) + min;
			        	if(randOne == 1) {
				        	aggroMoveBoard = game.gameState.playerTwoHomeboards.leftBoard;
				        } else {
				        	aggroMoveBoard = game.gameState.playerOneHomeboards.leftBoard;
				        }
				        max = 3;
			        	min = 0;
			        	range = max - min + 1;
			        	boolean validSpot = false;
				        while(!validSpot) {
				        	randOne = (int)(Math.random() * range) + min;
				        	randTwo = (int)(Math.random() * range) + min;
					        if(aggroMoveBoard.board[randOne][randTwo] == 'B') {
					            		validSpot = true;
					        }
				        }
				        randThree = (int)(Math.random() * range) + min;
			        	randFour = (int)(Math.random() * range) + min;
				        tempAggroMove = new AggressiveMove(tempPassMove, aggroMoveBoard, randOne, randTwo, randThree, randFour);
				        if(tempAggroMove.canMove()) {
				        	passMoveBoard.move(tempPassMove);
					    	game.movesPlayed.add(tempPassMove);
					    	aggroMoveBoard.move(tempAggroMove);
					    	game.movesPlayed.add(tempAggroMove);
				        	validSpot = true;
				        	validMove = true;
				        }
			        }
		        }
			}else { //computer player is white
				int max = 2; 
		        int min = 1; 
		        int range = max - min + 1; 
		        boolean validMove = false;
		        Board passMoveBoard = null;
		        Board aggroMoveBoard = null;
		        int randOne = 0;
		        int randTwo = 0;
		        int randThree = 0;
		        int randFour = 0;
		        PassiveMove tempPassMove = null;
		        AggressiveMove tempAggroMove;
				while(!validMove) {
					moveAttempts++;
					if(moveAttempts > 1000000) {
						game.setStatus(GameStatus.BLACK_WIN);
						validMove = true;
					}
					boolean validPassMove = false;
			        while(!validPassMove) {
			        	max = 2;
			        	min = 1;
			        	range = max - min + 1;
				        randOne = (int)(Math.random() * range) + min;
				        if(randOne == 1) {
				        	passMoveBoard = game.gameState.playerTwoHomeboards.leftBoard;
				        } else {
				        	passMoveBoard = game.gameState.playerTwoHomeboards.rightBoard;
				        }
				        max = 3;
			        	min = 0;
			        	range = max - min + 1;
			        	boolean validSpot = false;
				        while(!validSpot) {
				        	randOne = (int)(Math.random() * range) + min;
				        	randTwo = (int)(Math.random() * range) + min;
					        if(passMoveBoard.board[randOne][randTwo] == 'W') {
					            		validSpot = true;
					        }
				        }
			        	randThree = (int)(Math.random() * range) + min;
			        	randFour = (int)(Math.random() * range) + min;
			        	tempPassMove = new PassiveMove(game.currentTurn, passMoveBoard, randOne, randTwo, randThree, randFour);
				        if(tempPassMove.canMove()) {
				        	validPassMove = true;
				        }
			        }
			        if(passMoveBoard.isDark()) {//passive move was on dark coloured board
			        	max = 2;
			        	min = 1;
			        	range = max - min + 1;
			        	randOne = (int)(Math.random() * range) + min;
			        	if(randOne == 1) {
				        	aggroMoveBoard = game.gameState.playerTwoHomeboards.rightBoard;
				        } else {
				        	aggroMoveBoard = game.gameState.playerOneHomeboards.rightBoard;
				        }
				        max = 3;
			        	min = 0;
			        	range = max - min + 1;
			        	boolean validSpot = false;
				        while(!validSpot) {
				        	randOne = (int)(Math.random() * range) + min;
				        	randTwo = (int)(Math.random() * range) + min;
					        if(aggroMoveBoard.board[randOne][randTwo] == 'W') {
					            		validSpot = true;
					        }
				        }
				        randThree = (int)(Math.random() * range) + min;
			        	randFour = (int)(Math.random() * range) + min;
				        tempAggroMove = new AggressiveMove(tempPassMove, aggroMoveBoard, randOne, randTwo, randThree, randFour);
				        if(tempAggroMove.canMove()) {
				        	passMoveBoard.move(tempPassMove);
					    	game.movesPlayed.add(tempPassMove);
					    	aggroMoveBoard.move(tempAggroMove);
					    	game.movesPlayed.add(tempAggroMove);
				        	validSpot = true;
				        	validMove = true;
				        }
			        }else { //passive move was on light coloured board
			        	max = 2;
			        	min = 1;
			        	range = max - min + 1;
			        	randOne = (int)(Math.random() * range) + min;
			        	if(randOne == 1) {
				        	aggroMoveBoard = game.gameState.playerTwoHomeboards.leftBoard;
				        } else {
				        	aggroMoveBoard = game.gameState.playerOneHomeboards.leftBoard;
				        }
				        max = 3;
			        	min = 0;
			        	range = max - min + 1;
			        	boolean validSpot = false;
				        while(!validSpot) {
				        	randOne = (int)(Math.random() * range) + min;
				        	randTwo = (int)(Math.random() * range) + min;
					        if(aggroMoveBoard.board[randOne][randTwo] == 'W') {
					            		validSpot = true;
					        }
				        }
				        randThree = (int)(Math.random() * range) + min;
			        	randFour = (int)(Math.random() * range) + min;
				        tempAggroMove = new AggressiveMove(tempPassMove, aggroMoveBoard, randOne, randTwo, randThree, randFour);
				        if(tempAggroMove.canMove()) {
				        	passMoveBoard.move(tempPassMove);
					    	game.movesPlayed.add(tempPassMove);
					    	aggroMoveBoard.move(tempAggroMove);
					    	game.movesPlayed.add(tempAggroMove);
				        	validSpot = true;
				        	validMove = true;
				        }
			        }
		        }
			}
		}	
	}
	
	
	public static Game newGame() {
		Game newGame = new Game();
		newGame.initialize(new Player('B', false), new Player('W', false));
		return newGame;
	}
	
	public static boolean winner(Game game) { //checks if there is still a piece of the other player's on the boards to determine if win has occurred
		if(game.currentTurn.isBlack()) {
			if(!hasChar(game.gameState.playerOneHomeboards.leftBoard, 'W')) {
				blackTopLeftWin++;
				return true;
			}else if(!hasChar(game.gameState.playerOneHomeboards.rightBoard, 'W')) {
				blackTopRightWin++;
				return true;
			}else if(!hasChar(game.gameState.playerTwoHomeboards.leftBoard, 'W')) {
				blackBottomLeftWin++;
				return true;
			}else if(!hasChar(game.gameState.playerTwoHomeboards.rightBoard, 'W')) {
				blackBottomRightWin++;
				return true;
			}
		}else {
			if(!hasChar(game.gameState.playerOneHomeboards.leftBoard, 'B')) {
				whiteTopLeftWin++;
				return true;
			}else if(!hasChar(game.gameState.playerOneHomeboards.rightBoard, 'B')) {
				whiteTopRightWin++;
				return true;
			}else if(!hasChar(game.gameState.playerTwoHomeboards.leftBoard, 'B')) {
				whiteBottomLeftWin++;
				return true;
			}else if(!hasChar(game.gameState.playerTwoHomeboards.rightBoard, 'B')) {
				whiteBottomRightWin++;
				return true;
			}
		}
		return false;
	}
	
	public static boolean hasChar(Board board, char colour) {
		for (int row = 0; row < 4; row++)
        {
            for (int col = 0; col < 4; col++)
            {
            	if(board.board[row][col] == colour) {
            		return true;
            	}
            }	
        }
		return false;
	}
}
