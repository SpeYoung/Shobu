package shobu;

public class PassiveMove extends Move {// PassiveMove extends abstract Move, Shobu Passive Move

	public PassiveMove(Player player, Board board, int startX, int startY, int endX, int endY) {//constructor
		super(player, board, startX, startY, endX, endY);
	}

	@Override 
	public boolean canMove() { //returns true if move is valid passive move, false otherwise
		boolean oneSpaceMove = Math.abs(startX - endX) <= 1 && Math.abs(startY - endY) <= 1; //end space is within 1 space of start space
		boolean twoSpaceDiagonalMove = Math.abs(startX - endX) == 2 && Math.abs(startY - endY) == 2 && Math.abs(startX - endX) == Math.abs(startY - endY); //if end space is diagonal 2 from start space
		boolean twoSpaceStraightMove = Math.abs(startX - endX) + Math.abs(startY - endY) == 2; //if start space is straight 2 from end space
		if((player.isBlack() && board.quandrant == 'a') || (player.isBlack() && board.quandrant == 'b')) { //checks that passive move is on player's Homeboards
			return false;
		}
		else if((!player.isBlack() && board.quandrant == 'c') || (!player.isBlack() && board.quandrant == 'd')) { //if player is white
			return false;
		}
		if((oneSpaceMove ||  twoSpaceDiagonalMove || twoSpaceStraightMove)) { //if the start space is in range (within 2 spaces) of the end space move valid otherwise invalid
			if(!oneSpaceMove) {
				if(board.getSpace((startX + endX) / 2, (startY + endY) / 2) != ' ') {
					return false;
				}
			}
			if(player.isBlack()) {
				if(board.getSpace(startX, startY) == 'B' && board.getSpace(endX, endY) == ' ') {
					return true;
				}
			}
			else{
				if(board.getSpace(startX, startY) == 'W' && board.getSpace(endX, endY) == ' ') {
					return true;
				}
			}
		}
		return false;
	}
}