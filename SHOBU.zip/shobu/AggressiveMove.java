package shobu;

public class AggressiveMove extends Move {//AggressiveMove extends abstract Move, Shoubu Move
	Move passMove;
	Player targetPlayer;
	public AggressiveMove(Move passMove, Board board, int startX, int startY, int endX, int endY) { //constructor
		super(passMove.player, board, startX, startY, endX, endY);
		this.passMove = passMove;
	}

	@Override 
	public boolean canMove() { //returns true if move is valid Aggressive move, false otherwise
		int diffX = endX - startX;
		int diffY = endY - startY;		
		if(Math.atan2(diffY, diffX) != Math.atan2(passMove.endY - passMove.startY, passMove.endX - passMove.startX)) { // Passive move vector is not equivalent in direction to Aggressive move and invalidates if true
				return false; 
		}
		if(Math.sqrt(Math.pow(diffX, 2) + Math.pow(diffY, 2)) != Math.sqrt(Math.pow(passMove.endX - passMove.startX, 2) + Math.pow(passMove.endY - passMove.startY, 2))) { // Passive move vector is not equivalent in distance to Aggressive move and invalidates if true
			return false;
		}
		boolean oneSpaceMove = Math.abs(diffX) <= 1 && Math.abs(diffY) <= 1; //true if end space is within 1 space of start space
		boolean twoSpaceDiagonalMove = Math.abs(diffX) == 2 && Math.abs(diffY) == 2; //true if end space is diagonal 2 from start space
		boolean twoSpaceStraightMove = Math.abs(diffX) + Math.abs(diffY) == 2; //true if start space is straight 2 from end space
		if(passMove.board.colour == board.colour) { //if the Aggressive move is on the same colour board as the Passive move returns false (invalid move)
			return false;
		}
		if((oneSpaceMove ||  twoSpaceDiagonalMove || twoSpaceStraightMove)) { //if the start space is in range (within 2 spaces) of the end space move valid otherwise invalid
			int midX = (startX + endX) / 2;
			int midY = (startY+ endY) / 2;
			if(!oneSpaceMove) {
				if(board.getSpace(midX, midY) != ' ' && board.getSpace(endX, endY) != ' ') { //if there are two stones in path can't move (two space move)
					return false;
				}
			}
			if(player.isBlack()) {
				if(board.getSpace(startX, startY) == 'B' && board.getSpace(endX, endY) == ' ') {
					if(oneSpaceMove) {
						return true;
					}else if(board.getSpace(midX, midY) == ' ') {
						return true;
					}else if(board.getSpace(midX, midY) == 'W') {
						if(midX + diffX >= 0 && midX + diffX < 4 && midY + diffY >= 0 && midY + diffY < 4) {
							if(board.getSpace(midX + diffX, midY + diffY) == ' ') {
								board.board[midX + diffX][midY + diffY] = 'W'; // push into open space
								board.board[midX][midY] = ' ';
								return true; //move rock
							}
							else {
								return false; //invalid move space is full
							}
						}else {
							board.board[midX][midY] = ' ';
							return true; //valid move will push rock off board
						}						
					}
				}
				else if(board.getSpace(startX, startY) == 'B' && board.getSpace(endX, endY) == 'W') {
					if(oneSpaceMove) {
						if(endX + diffX >= 0 && endX + diffX < 4 && endY + diffY >= 0 && endY + diffY < 4) {
							if(board.getSpace(endX + diffX, endY + diffY) == ' ') {
								board.board[endX + diffX][endY + diffY] = 'W'; // push into open space
								return true; //move rock
							}
							else {
								return false; //invalid move space is full
							}
						}else {
							return true; //valid move will push rock off board
						}
					}else {
						if(midX + diffX >= 0 && midX + diffX < 4 && midY + diffY >= 0 && midY + diffY < 4) {
							if(board.getSpace(midX + diffX, midY + diffY) == ' ') {
								board.board[midX + diffX][midY + diffY] = 'W'; // push into open space
								return true; //move rock
							}
							else {
								return false; //invalid move space is full
							}
						}else {
							return true; //valid move will push rock off board
						}
					}
				}
			}
			else{ //player white
				if(board.getSpace(startX, startY) == 'W' && board.getSpace(endX, endY) == ' ') { //start space is White stone end space is empty
					if(oneSpaceMove) {
						return true;
					}else if(board.getSpace(midX, midY) == ' ') {
						return true;
					}else if(board.getSpace(midX, midY) == 'B') {
						if(midX + diffX >= 0 && midX + diffX < 4 && midY + diffY >= 0 && midY + diffY < 4) {
							if(board.getSpace(midX + diffX, midY + diffY) == ' ') {
								board.board[midX + diffX][midY + diffY] = 'B'; // push into open space
								board.board[midX][midY] = ' ';
								return true; //move rock
							}
							else {
								return false; //invalid move space is full
							}
						}else {
							board.board[midX][midY] = ' ';
							return true; //valid move will push rock off board
						}						
					}
				}
				else if(board.getSpace(startX, startY) == 'W' && board.getSpace(endX, endY) == 'B') { //Start space White stone end space is Black stone
					if(oneSpaceMove) {
						if(endX + diffX >= 0 && endX + diffX < 4 && endY + diffY >= 0 && endY + diffY < 4) {
							if(board.getSpace(endX + diffX, endY + diffY) == ' ') {
								board.board[endX + diffX][endY + diffY] = 'B'; // push into open space
								return true; //move rock
							}
							else {
								return false; //invalid move space is full
							}
						}else {
							return true; //valid move will push rock off board
						}
					}else {
						if(midX + diffX >= 0 && midX + diffX < 4 && midY + diffY >= 0 && midY + diffY < 4) {
							if(board.getSpace(midX + diffX, midY + diffY) == ' ') {
								board.board[midX + diffX][midY + diffY] = 'B'; // push into open space
								return true; //move rock
							}
							else {
								return false; //invalid move space is full
							}
						}else {
							return true; //valid move will push rock off board
						}
					}
				}
			}
		}
		return false; //invalid move (not valid)
	}
}