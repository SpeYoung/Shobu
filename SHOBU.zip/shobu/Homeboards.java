package shobu;

public class Homeboards { //Two Board objects together (left and right)
	Board leftBoard;
	Board rightBoard;
	
	public Homeboards(Board firstBoard, Board secondBoard) { //Constructor uses Board Constructor
		leftBoard = firstBoard;
		rightBoard = secondBoard;
	}
	
	public String toString() { //String representation of a player's Homeboards
		StringBuffer HomeboardsString = new StringBuffer();
		HomeboardsString.append("--------- ---------" + System.lineSeparator());
		for(int r=0; r<leftBoard.board.length; r++) {
			for(int c=0; c<leftBoard.board[r].length; c++) {
				HomeboardsString.append("|" + leftBoard.board[r][c]);
			}
			HomeboardsString.append("| ");
			for(int c=0; c<rightBoard.board[r].length; c++) {
				HomeboardsString.append("|" + rightBoard.board[r][c]);
			}
			if(r < leftBoard.board.length-1) {
				HomeboardsString.append('|' + System.lineSeparator() + "|-+-+-+-| |-+-+-+-|" + System.lineSeparator());
			}
		}
		HomeboardsString.append('|' + System.lineSeparator() + "--------- ---------" + System.lineSeparator());
		return HomeboardsString.toString();
	}
}
